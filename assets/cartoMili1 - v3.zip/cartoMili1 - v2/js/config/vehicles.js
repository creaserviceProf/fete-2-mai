import { enemyVehiclesCatalog } from './enemyVehicles.js';

export const vehiclesCatalog = [
    {
        id: "v_suv",
        name: "SUV Tactique",
        category: "Léger",
        side: "friend",
        rangeKm: 5,
        scale: 2,
        modelUrl: "js/assets/rapidranger.glb",
        image: "js/assets/rapidranger.jpg",
        fallbackColor: 0x4a90e2,
        fallbackType: "box",
        dimensions: { length: 4.5, width: 2, height: 1.8 }
    },
    {
        id: "v_tent",
        name: "Tente Tactique",
        category: "Léger",
        side: "friend",
        rangeKm: 1,
        scale: 10,
        modelUrl: "js/assets/tenteC2.glb",
        image: "js/assets/c2Tent.jpg",
        fallbackColor: 0x333333,
        fallbackType: "box",
        dimensions: { length: 4.5, width: 2, height: 1.8 }
    },
    {
        id: "v_truck",
        name: "Camion Logistique",
        category: "Lourd",
        side: "friend",
        rangeKm: 8,
        scale: 1,
        modelUrl: "",
        image: "",
        fallbackColor: 0x27ae60,
        fallbackType: "box",
        dimensions: { length: 8, width: 2.5, height: 3.2 }
    },
    {
        id: "v_armor",
        name: "Véhicule Blindé",
        category: "Combat",
        side: "friend",
        rangeKm: 20,
        scale: 6,
        modelUrl: "js/assets/lancemissile1.glb",
        image: "js/assets/lancemissile1.jpg",
        fallbackColor: 0xc0392b,
        fallbackType: "box",
        dimensions: { length: 18, width: 16.8, height: 15 }
    }
];

export { enemyVehiclesCatalog };

export function getVehicleById(id) {
    const combined = [...vehiclesCatalog, ...enemyVehiclesCatalog];
    return combined.find(v => v.id === id);
}
