export const enemyVehiclesCatalog = [
    {
        id: "e_tank",
        name: "Char Ennemi T-90",
        category: "Combat",
        side: "enemy",
        rangeKm: 6,
        scale: 2,
        modelUrl: "js/assets/chart90.glb",
        image: "js/assets/chart90.jpg",
        fallbackColor: 0x800000,
        fallbackType: "box",
        dimensions: { length: 9.5, width: 3.8, height: 2.2 }
    },
    {
        id: "e_btr",
        name: "Blindé Ennemi BTR",
        category: "Transport",
        side: "enemy",
        rangeKm: 4,
        scale: 0.2,
        modelUrl: "js/assets/bm-30_smerch_8x8.glb",
        image: "js/assets/bm-30_smerch_8x8.jpg",
        fallbackColor: 0x660000,
        fallbackType: "box",
        dimensions: { length: 7.5, width: 2.8, height: 2.4 }
    },
    {
        id: "e_radar",
        name: "Radar Mobile Ennemi",
        category: "Support",
        side: "enemy",
        rangeKm: 25,
        scale: 2,
        modelUrl: "",
        image: "",
        fallbackColor: 0x990000,
        fallbackType: "box",
        dimensions: { length: 10, width: 3, height: 4 }
    }
];
