# CartoMili 3D V1

Application de cartographie 3D interactive permettant le placement, l'édition et la sauvegarde de véhicules sur le terrain, en utilisant Mapbox GL JS et Three.js.

## Lancement

L'application utilise des Modules ES (`import` / `export`). Pour éviter les restrictions de sécurité du navigateur (CORS pour les modules locaux), **il faut servir les fichiers via un serveur local HTTP**.

**Méthode la plus simple avec VSCode :**
1. Installez l'extension **Live Server**.
2. Ouvrez le dossier `cartoMili1`.
3. Cliquez droit sur `index.html` > *Open with Live Server*.

**Méthode avec Node.js :**
```bash
npx serve .
```

## Structure
- `index.html` : Entrée principale et UI.
- `css/style.css` : Styles UI métier sombres.
- `js/app.js` : Bootstrap de l'application.
- `js/store.js` : Gestion de l'état applicatif (mode, sélection, liste).
- `js/modules/map.js` : Configuration Mapbox et proxy layer GeoJSON pour la sélection.
- `js/modules/threeLayer.js` : CustomLayer Mapbox injectant Three.js et affichant les modèles.
- `js/modules/ui.js` : Logique DOM de l'interface.
- `js/modules/persistence.js` : Export/Import JSON.
- `js/config/vehicles.js` : Catalogue des assets.

## Limitations Actuelles (V1)
- **Modèles 3D** : Utilisation de primitives géométriques (Box) par défaut pour assurer une stabilité totale en l'absence de fichiers `.glb` testés. Le code GLTFLoader est commenté dans `threeLayer.js` prêt à être activé en configurant les `modelUrl`.
- **Relief et Ombre** : Le *shadow plane* est un plan 2D au sol en dessous du mesh. Avec le relief montagneux Mapbox, le plan peut légèrement intersecter le sol en cas de forte pente (z-fighting inévitable sans calcul complexe de normale terrain).
- **Sélection** : La sélection est basée sur une couche proxy Mapbox GeoJSON (cercles) plutôt que sur un raycaster Three.js pur. C'est infiniment plus robuste en contexte Mercator + Terrain 3D Mapbox pour une V1.
