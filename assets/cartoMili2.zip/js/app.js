import { initMap } from './modules/map.js';
import { initUI } from './modules/ui.js';

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialiser l'interface UI (panneaux, boutons)
    initUI();

    // 2. Gérer le token Mapbox (Prompt s'il n'est pas codé en dur)
    let mapboxToken = 'pk.eyJ1Ijoia2lraXN0ZWYiLCJhIjoiY2t1aTJ3eHltMDV3ODJ3cGUxemUzZWl3OSJ9.8-ngOMPn_Uk_LMavuCIpbQ'; 

    // Fallback: si le token n'est pas défini, demander à l'utilisateur
    if (!mapboxToken || mapboxToken === 'YOUR_MAPBOX_TOKEN') {
        const overlay = document.getElementById('ui-overlay');
        overlay.classList.remove('hidden');

        document.getElementById('btn-submit-token').addEventListener('click', () => {
            const input = document.getElementById('input-mapbox-token').value;
            if (input && input.startsWith('pk.')) {
                overlay.classList.add('hidden');
                initMap(input);
            } else {
                alert("Token invalide. Il doit commencer par 'pk.'");
            }
        });
    } else {
        // Initialiser directement
        initMap(mapboxToken);
    }
});
