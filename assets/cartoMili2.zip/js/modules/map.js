import { store } from '../store.js';
import { getVehicleById } from '../config/vehicles.js';
import { createThreeLayer } from './threeLayer.js';

let mapInstance = null;
let threeLayer = null; // Référence globale pour reconstruction après changement de style

export function initMap(token) {
    mapboxgl.accessToken = token;

    mapInstance = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/kikistef/cm6f5p5a600b801qx7s6cctkq',
        center: [2.3522, 48.8566],
        zoom: 12,
        pitch: 60,
        bearing: 0,
        antialias: true
    });

    mapInstance.on('load', () => {
        // Ajouter le relief 3D seulement s'il n'existe pas déjà dans le style
        if (!mapInstance.getSource('mapbox-dem')) {
            mapInstance.addSource('mapbox-dem', {
                'type': 'raster-dem',
                'url': 'mapbox://mapbox.mapbox-terrain-dem-v1',
                'tileSize': 512,
                'maxzoom': 20
            });
        }

        // Activer le terrain si pas déjà activé
        if (!mapInstance.getTerrain()) {
            mapInstance.setTerrain({ 'source': 'mapbox-dem', 'exaggeration': 0 });
        }

        // Initialiser la couche Three.js
        threeLayer = createThreeLayer(mapInstance);
        mapInstance.addLayer(threeLayer);

        // Initialiser la couche GeoJSON proxy pour la sélection et portée
        initProxyLayer();

        // Gérer le placement
        mapInstance.on('dblclick', handleMapDoubleClick);

        // Gérer la sélection
        mapInstance.on('click', 'vehicle-markers-dot', handleVehicleClick);

        // Gérer la désélection (clic à côté) OU sélection 3D
        mapInstance.on('click', (e) => {
            // 1. Vérifier si on a cliqué sur un point 2D (déjà géré par handleVehicleClick, mais on vérifie pour la désélection)
            const features = mapInstance.queryRenderedFeatures(e.point, { layers: ['vehicle-markers-dot'] });
            
            // 2. Vérifier si on a cliqué sur un modèle 3D (Raycasting)
            const hitId = threeLayer.raycast(e.point);

            if (features.length === 0 && !hitId) {
                store.setState({ selectedPlacedId: null });
            } else if (hitId) {
                store.setState({ selectedPlacedId: hitId });
            }
        });

        // Change cursor
        mapInstance.on('mouseenter', 'vehicle-markers-dot', () => {
            mapInstance.getCanvas().style.cursor = 'pointer';
        });
        mapInstance.on('mouseleave', 'vehicle-markers-dot', () => {
            mapInstance.getCanvas().style.cursor = '';
        });

        // Sync placed vehicles to proxy layer
        store.subscribe('placedVehicles', updateProxyLayer);
        store.subscribe('selectedPlacedId', updateProxyLayerSelection);

        // Gérer l'exagération du terrain
        store.subscribe('terrainExaggeration', (exag) => {
            if (mapInstance && mapInstance.getSource('mapbox-dem')) {
                mapInstance.setTerrain({ 'source': 'mapbox-dem', 'exaggeration': exag });

                // Si on active le relief, on doit recalculer les altitudes des véhicules
                if (exag > 0) {
                    // On attend que la carte ait fini de charger les nouvelles tuiles de relief
                    mapInstance.once('idle', () => {
                        const state = store.getState();
                        const updatedVehicles = state.placedVehicles.map(v => {
                            const elev = mapInstance.queryTerrainElevation([v.lng, v.lat]) || 0;
                            // On stocke l'altitude brute (elev / exag)
                            return { ...v, terrainAltitude: elev / exag };
                        });
                        store.setPlacedVehicles(updatedVehicles);
                        console.log("Altitudes synchronisées avec le relief.");
                    });
                }
            }
        });

        store.subscribe('focus_camera', (id) => {
            const vData = store.getState().placedVehicles.find(v => v.instanceId === id);
            if (vData && mapInstance) {
                mapInstance.flyTo({
                    center: [vData.lng, vData.lat],
                    zoom: 20,
                    speed: 1.2
                });
            }
        });

        // Chargement d'une scène JSON : focus caméra + repaint forcé
        store.subscribe('scene_loaded', (vehicles) => {
            if (!vehicles || vehicles.length === 0 || !mapInstance) return;

            // 1. Forcer le repaint pour que Three.js rende les véhicules immédiatement
            mapInstance.triggerRepaint();

            // 2. Calculer la bounding box de tous les véhicules
            const lngs = vehicles.map(v => v.lng);
            const lats = vehicles.map(v => v.lat);
            const minLng = Math.min(...lngs);
            const maxLng = Math.max(...lngs);
            const minLat = Math.min(...lats);
            const maxLat = Math.max(...lats);

            if (vehicles.length === 1) {
                // Un seul véhicule : flyTo simple
                mapInstance.flyTo({
                    center: [lngs[0], lats[0]],
                    zoom: 17,
                    pitch: 60,
                    speed: 1.2
                });
            } else {
                // Plusieurs véhicules : fitBounds
                mapInstance.fitBounds(
                    [[minLng, minLat], [maxLng, maxLat]],
                    { padding: 120, pitch: 60, duration: 2000 }
                );
            }

            // 3. Re-forcer le repaint après la fin de l'animation
            mapInstance.once('idle', () => mapInstance.triggerRepaint());
        });

        console.log("Map chargée.");

        // Mettre à jour l'overlay du zoom
        const updateZoomOverlay = () => {
            document.getElementById('val-zoom').innerText = mapInstance.getZoom().toFixed(2);
        };

        mapInstance.on('zoom', updateZoomOverlay);
        updateZoomOverlay();

        // Geocoder search
        initGeocoder();

        // Style switcher
        initStyleSwitcher();
    });
}

function initGeocoder() {
    const input = document.getElementById('geocoder-input');
    const btn = document.getElementById('btn-geocoder');

    const doSearch = () => {
        const query = input.value.trim();
        if (!query || !mapInstance) return;

        const token = mapboxgl.accessToken;
        const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(query)}.json?access_token=${token}&limit=1&language=fr`;

        fetch(url)
            .then(r => r.json())
            .then(data => {
                if (data.features && data.features.length > 0) {
                    const [lng, lat] = data.features[0].center;
                    mapInstance.flyTo({ center: [lng, lat], zoom: 14, pitch: 60, speed: 1.2 });
                } else {
                    alert('Lieu introuvable : ' + query);
                }
            })
            .catch(() => alert('Erreur lors de la recherche.'));
    };

    btn.addEventListener('click', doSearch);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });
}

function initStyleSwitcher() {
    const buttons = document.querySelectorAll('.style-btn');

    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            const newStyle = btn.dataset.style;
            if (!newStyle || !mapInstance) return;

            // Marquer le bouton actif
            buttons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Mémoriser la caméra actuelle
            const center = mapInstance.getCenter();
            const zoom = mapInstance.getZoom();
            const bearing = mapInstance.getBearing();
            const pitch = mapInstance.getPitch();

            // Changer le style
            mapInstance.setStyle(newStyle);

            // Réinitialiser les sources et couches après le chargement du nouveau style
            mapInstance.once('style.load', () => {
                if (!mapInstance.getSource('mapbox-dem')) {
                    mapInstance.addSource('mapbox-dem', {
                        'type': 'raster-dem',
                        'url': 'mapbox://mapbox.mapbox-terrain-dem-v1',
                        'tileSize': 512,
                        'maxzoom': 20
                    });
                }

                const state = store.getState();
                if (state.terrainExaggeration > 0) {
                    mapInstance.setTerrain({ 'source': 'mapbox-dem', 'exaggeration': state.terrainExaggeration });
                }

                // Restaurer la caméra
                mapInstance.jumpTo({ center, zoom, bearing, pitch });

                // Recréer le layer Three.js (détruit par setStyle)
                // Note: setStyle le supprime automatiquement, mais onRemove n'est pas appelé
                // On appelle manuellement onRemove pour désactiver l'ancien layer
                if (threeLayer && threeLayer.onRemove) threeLayer.onRemove();
                threeLayer = createThreeLayer(mapInstance);
                mapInstance.addLayer(threeLayer);

                // Recréer les couches proxy GeoJSON
                initProxyLayer();
                store.notify('placedVehicles', store.getState().placedVehicles);

                // Forcer repaint pour afficher les véhicules 3D
                mapInstance.once('idle', () => mapInstance.triggerRepaint());
            });
        });
    });
}

function handleMapDoubleClick(e) {
    const state = store.getState();
    if (state.mode === 'placement' && state.selectedCatalogId) {
        e.preventDefault(); // Prevent default map double-click zoom

        const lngLat = e.lngLat;
        let alt = 0;

        // Requête altitude
        const elevation = mapInstance.queryTerrainElevation(lngLat) || 0;
        const currentExag = state.terrainExaggeration || 1.0;
        const rawAlt = (state.terrainExaggeration > 0) ? (elevation / state.terrainExaggeration) : 0;

        const newVehicle = {
            instanceId: 'v_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            catalogId: state.selectedCatalogId,
            lng: lngLat.lng,
            lat: lngLat.lat,
            terrainAltitude: rawAlt,
            altitudeOffset: 0,
            heading: 0,
            rotationX: 0,
            rotationY: 0,
            offsetX: 0,
            offsetY: 0,
            timestamp: Date.now()
        };

        store.addPlacedVehicle(newVehicle);

        // Revenir en mode idle
        store.setState({ mode: 'idle' });
    }
}

function handleVehicleClick(e) {
    const state = store.getState();
    if (state.mode === 'placement') return; // Ne pas sélectionner en plein placement

    const feature = e.features[0];
    if (feature && feature.properties && feature.properties.instanceId) {
        store.setState({ selectedPlacedId: feature.properties.instanceId });
        e.preventDefault(); // Stop propagation
    }
}

function initProxyLayer() {
    mapInstance.addSource('vehicles-geojson', {
        type: 'geojson',
        data: {
            type: 'FeatureCollection',
            features: []
        }
    });

    // On garde uniquement les ronds rouges pour l'interaction 2D
    mapInstance.addLayer({
        id: 'vehicle-markers-dot',
        type: 'circle',
        source: 'vehicles-geojson',
        paint: {
            'circle-radius': [
                'case',
                ['==', ['coalesce', ['get', 'selected'], false], true],
                10,
                6
            ],
            'circle-color': ['coalesce', ['get', 'color'], '#e74c3c'],
            'circle-stroke-width': [
                'case',
                ['==', ['coalesce', ['get', 'selected'], false], true],
                3,
                2
            ],
            'circle-stroke-color': '#ffffff',
            'circle-opacity': 0.9
        }
    });

    // Couche pour le clic (hitbox plus grosse)
    mapInstance.addLayer({
        id: 'vehicle-points',
        type: 'circle',
        source: 'vehicles-geojson',
        paint: {
            'circle-radius': 15,
            'circle-color': '#000000',
            'circle-opacity': 0 // Invisible mais cliquable
        }
    });
}

let hoveredStateId = null;

function updateProxyLayer(vehicles) {
    if (!mapInstance || !mapInstance.getSource('vehicles-geojson')) return;

    const features = vehicles.map(v => {
        const catalog = getVehicleById(v.catalogId);
        const colorStr = catalog ? '#' + catalog.fallbackColor.toString(16).padStart(6, '0') : '#e74c3c';

        // Calcul de la position avec offsets
        const coord = mapboxgl.MercatorCoordinate.fromLngLat([v.lng, v.lat]);
        const unitsPerMeter = coord.meterInMercatorCoordinateUnits();
        coord.x += (v.offsetX || 0) * unitsPerMeter;
        coord.y -= (v.offsetY || 0) * unitsPerMeter; // Inversion Nord/Sud
        const finalLngLat = coord.toLngLat();

        // Générer un ID numérique court pour Mapbox feature-state
        const numericId = parseInt(v.instanceId.split('_')[1]) || 0;

        return {
            type: 'Feature',
            id: numericId,
            properties: {
                instanceId: v.instanceId,
                rangeKm: catalog ? catalog.rangeKm : 0,
                color: colorStr
            },
            geometry: {
                type: 'Point',
                coordinates: [finalLngLat.lng, finalLngLat.lat]
            }
        };
    });

    mapInstance.getSource('vehicles-geojson').setData({
        type: 'FeatureCollection',
        features: features
    });
}

function updateProxyLayerSelection(selectedId) {
    if (!mapInstance || !mapInstance.getSource('vehicles-geojson')) return;
    
    const state = store.getState();
    const source = mapInstance.getSource('vehicles-geojson');

    const features = state.placedVehicles.map(v => {
        const catalog = getVehicleById(v.catalogId);
        const colorStr = catalog ? '#' + catalog.fallbackColor.toString(16).padStart(6, '0') : '#e74c3c';
        const isSelected = v.instanceId === selectedId;
        
        const coord = mapboxgl.MercatorCoordinate.fromLngLat([v.lng, v.lat]);
        const unitsPerMeter = coord.meterInMercatorCoordinateUnits();
        coord.x += (v.offsetX || 0) * unitsPerMeter;
        coord.y -= (v.offsetY || 0) * unitsPerMeter; // Inversion pour match Three.js (Nord = positif)
        const finalPos = coord.toLngLat();

        return {
            type: 'Feature',
            id: parseInt(v.instanceId.split('_')[1]) || 0,
            properties: {
                instanceId: v.instanceId,
                rangeKm: catalog ? catalog.rangeKm : 0,
                color: colorStr,
                selected: isSelected
            },
            geometry: {
                type: 'Point',
                coordinates: [finalPos.lng, finalPos.lat]
            }
        };
    });

    source.setData({
        type: 'FeatureCollection',
        features: features
    });
}
