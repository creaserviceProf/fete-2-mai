import { store } from '../store.js';
import { getVehicleById } from '../config/vehicles.js';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export function createThreeLayer(mapInstance) {

    const layerId = '3d-vehicles-layer';
    let camera, scene, renderer;
    let map = mapInstance;

    const meshes = new Map();
    const loader = new GLTFLoader();

    // Point d'ancrage pour la précision
    let anchorLngLat = null;
    let anchorMercator = null;
    let active = true; // Flag pour désactiver ce layer si un nouveau est créé

    const customLayer = {
        id: layerId,
        type: 'custom',
        renderingMode: '3d',

        onAdd: function (map, gl) {
            this.map = map;

            camera = new THREE.Camera();
            scene = new THREE.Scene();

            renderer = new THREE.WebGLRenderer({
                canvas: map.getCanvas(),
                context: gl,
                antialias: true
            });
            renderer.autoClear = false;
            renderer.shadowMap.enabled = true;
            renderer.shadowMap.type = THREE.PCFSoftShadowMap;

            const light = new THREE.DirectionalLight(0xffffff, 2.0);
            light.position.set(200, 200, 500);
            light.castShadow = true;

            // Rétablissement des paramètres de la caméra d'ombre pour couvrir une zone large
            light.shadow.camera.left = -500;
            light.shadow.camera.right = 500;
            light.shadow.camera.top = 500;
            light.shadow.camera.bottom = -500;
            light.shadow.camera.near = 1;
            light.shadow.camera.far = 1500;

            light.shadow.mapSize.width = 2048;
            light.shadow.mapSize.height = 2048;
            light.shadow.bias = -0.0005; // Ajustement du biais
            scene.add(light);

            const light2 = new THREE.DirectionalLight(0xadd8e6, 1.0);
            light2.position.set(-200, -200, 300);
            scene.add(light2);

            // Lumière d'ambiance plus riche
            scene.add(new THREE.AmbientLight(0xffffff, 0.3));
            scene.add(new THREE.HemisphereLight(0xffffff, 0x444444, 0.5));

            // PointLight intense pour créer le point de réflexion "Glass"
            const pointLight = new THREE.PointLight(0xffffff, 1000, 0, 2);
            pointLight.position.set(0, 0, 1000);
            scene.add(pointLight);

            store.subscribe('placedVehicles', (vehicles) => {
                if (!active) return; // Layer remplacé : ignorer
                if (vehicles.length === 0) {
                    anchorLngLat = null;
                    anchorMercator = null;
                } else if (!anchorLngLat) {
                    anchorLngLat = [vehicles[0].lng, vehicles[0].lat];
                    anchorMercator = mapboxgl.MercatorCoordinate.fromLngLat(anchorLngLat, 0);
                }
                this.syncVehicles(vehicles);
                this.map.triggerRepaint();
            });

            store.subscribe('terrainExaggeration', () => {
                if (!active) return;
                const state = store.getState();
                this.syncVehicles(state.placedVehicles);
                this.map.triggerRepaint();
            });

            // Synchronisation immédiate si des véhicules existent déjà dans le store
            // (utile après un changement de style ou rechargement de layer)
            const initVehicles = store.getState().placedVehicles;
            if (initVehicles.length > 0) {
                anchorLngLat = [initVehicles[0].lng, initVehicles[0].lat];
                anchorMercator = mapboxgl.MercatorCoordinate.fromLngLat(anchorLngLat, 0);
                this.syncVehicles(initVehicles);
                setTimeout(() => this.map.triggerRepaint(), 100);
            }
        },

        onRemove: function () {
            active = false;
            meshes.clear();
        },

        render: function (gl, matrix) {
            if (!anchorMercator) return;

            // Mettre à jour les animations des cercles de portée à chaque frame
            const selectedId = store.getState().selectedPlacedId;
            for (const [id, group] of meshes.entries()) {
                const rangeGroup = group.getObjectByName("rangeGroup");
                const modelGroup = group.getObjectByName("modelGroup");
                const catalogItem = getVehicleById(group._catalogId);

                if (id === selectedId) {
                    // Highlight 3D (Effet émissif)
                    if (modelGroup) {
                        modelGroup.traverse(child => {
                            if (child.isMesh && child.material && child.material.emissive) {
                                if (child._origEmissive === undefined) child._origEmissive = child.material.emissive.getHex();
                                child.material.emissive.setHex(0x333333);
                            }
                        });
                    }

                    if (rangeGroup && !rangeGroup.visible) {
                        rangeGroup.visible = true;
                        rangeGroup._startTime = performance.now();
                    }

                    if (rangeGroup) {
                        const elapsed = performance.now() - rangeGroup._startTime;
                        const duration = 3200;
                        const progress = Math.min(elapsed / duration, 1);
                        const animFactor = progress === 1 ? 1 : 1 - Math.pow(1 - progress, 5);
                        const targetScale = (catalogItem?.rangeKm || 0) * 1000;

                        rangeGroup.scale.set(targetScale * animFactor, targetScale * animFactor, targetScale * animFactor);
                        if (progress < 1) this.map.triggerRepaint();
                    }
                } else {
                    if (modelGroup) {
                        modelGroup.traverse(child => {
                            if (child.isMesh && child.material && child.material.emissive && child._origEmissive !== undefined) {
                                child.material.emissive.setHex(child._origEmissive);
                            }
                        });
                    }
                    if (rangeGroup) {
                        rangeGroup.visible = false;
                        rangeGroup._startTime = null;
                    }
                }
            }

            // FACTEUR DE SCALE : Nombre de "Mercator units" pour 1 mètre à cette latitude
            const mPerUnit = anchorMercator.meterInMercatorCoordinateUnits();

            // MATRICE DE TRANSFORMATION RTC (Relative to Center)
            // On veut transformer le repère Three.js (mètres) vers le repère Mapbox (Mercator [0,1])
            // X: Est (+), Y: Nord (+), Z: Haut (+)
            const rtcMatrix = new THREE.Matrix4()
                .makeTranslation(anchorMercator.x, anchorMercator.y, anchorMercator.z)
                .scale(new THREE.Vector3(mPerUnit, -mPerUnit, mPerUnit)); // -mPerUnit car Mapbox Y est vers le Sud

            // On combine la matrice de projection Mapbox avec notre transformation locale
            const m = new THREE.Matrix4().fromArray(matrix);
            camera.projectionMatrix = m.multiply(rtcMatrix);

            renderer.resetState();
            renderer.render(scene, camera);
            this.map.triggerRepaint();
        },

        // Méthode de Raycasting pour la sélection au clic sur les modèles 3D
        raycast: function (point) {
            if (!anchorMercator || !meshes.size) return null;

            const mouse = new THREE.Vector2();
            mouse.x = (point.x / map.getCanvas().clientWidth) * 2 - 1;
            mouse.y = -(point.y / map.getCanvas().clientHeight) * 2 + 1;

            const raycaster = new THREE.Raycaster();
            raycaster.setFromCamera(mouse, camera);

            // Intersecter tous les groupes de véhicules
            const intersects = raycaster.intersectObjects(Array.from(meshes.values()), true);

            if (intersects.length > 0) {
                // Filtrer pour n'accepter que les hits dans le 'modelGroup'
                const validHit = intersects.find(hit => {
                    let parent = hit.object;
                    while (parent) {
                        if (parent.name === "modelGroup") return true;
                        parent = parent.parent;
                    }
                    return false;
                });

                if (validHit) {
                    let obj = validHit.object;
                    while (obj && !meshes.has(obj._instanceId) && obj.parent) {
                        obj = obj.parent;
                    }

                    if (obj && obj._instanceId) {
                        return obj._instanceId;
                    }
                }
            }
            return null;
        },

        syncVehicles: function (vehiclesData) {
            if (!anchorMercator) return;

            const currentIds = new Set(vehiclesData.map(v => v.instanceId));

            for (const [id, group] of meshes.entries()) {
                if (!currentIds.has(id)) {
                    scene.remove(group);
                    meshes.delete(id);
                }
            }

            vehiclesData.forEach(vData => {
                const catalogItem = getVehicleById(vData.catalogId);
                if (!catalogItem) return;

                if (!meshes.has(vData.instanceId)) {
                    const group = new THREE.Group();

                    // Sous-groupe pour le modèle (qui subit les rotations X, Y, Z)
                    const modelGroup = new THREE.Group();
                    modelGroup.name = "modelGroup";
                    group.add(modelGroup);

                    // ON TRAVAILLE EN MÈTRES RÉELS (1 unit = 1 meter)
                    const geom = new THREE.BoxGeometry(
                        catalogItem.dimensions.width,
                        catalogItem.dimensions.length,
                        catalogItem.dimensions.height
                    );
                    const mat = new THREE.MeshStandardMaterial({ color: catalogItem.fallbackColor, side: THREE.DoubleSide });
                    const mesh = new THREE.Mesh(geom, mat);
                    mesh.castShadow = true;
                    mesh.receiveShadow = true;
                    modelGroup.add(mesh);

                    const noseGeom = new THREE.BoxGeometry(
                        catalogItem.dimensions.width * 0.5,
                        catalogItem.dimensions.length * 0.2,
                        catalogItem.dimensions.height * 0.2
                    );
                    const noseMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
                    const nose = new THREE.Mesh(noseGeom, noseMat);
                    nose.position.y = catalogItem.dimensions.length / 2;
                    nose.castShadow = true;
                    modelGroup.add(nose);

                    // PLAN DE RÉCEPTION D'OMBRE (ShadowMaterial - non interactif)
                    const shadowGeom = new THREE.PlaneGeometry(catalogItem.dimensions.width * 20, catalogItem.dimensions.length * 20);
                    const shadowMat = new THREE.ShadowMaterial({ opacity: 0.4 });
                    const shadowPlane = new THREE.Mesh(shadowGeom, shadowMat);
                    shadowPlane.position.z = 0.1;
                    shadowPlane.receiveShadow = true;
                    shadowPlane.raycast = () => {}; // Exclure du raycasting
                    group.add(shadowPlane);

                    // CERCLE DE PORTÉE 3D (Animé)
                    const rangeGroup = new THREE.Group();
                    rangeGroup.name = "rangeGroup";
                    rangeGroup.visible = false;
                    group.add(rangeGroup);
                    group._catalogId = vData.catalogId; // Sauvegarder pour l'anim
                    group._instanceId = vData.instanceId; // Sauvegarder pour le raycast

                    // Remplissage transparent
                    const rangeFillGeom = new THREE.CircleGeometry(1, 64);
                    const rangeFillMat = new THREE.MeshBasicMaterial({
                        color: catalogItem.fallbackColor,
                        transparent: true,
                        opacity: 0.05,
                        side: THREE.DoubleSide
                    });
                    const rangeFill = new THREE.Mesh(rangeFillGeom, rangeFillMat);
                    rangeFill.raycast = () => {}; // Non interactif
                    rangeGroup.add(rangeFill);

                    // SPHÈRE DE PORTÉE (Dôme 3D - Effet Verre Réel)
                    const rangeSphereGeom = new THREE.SphereGeometry(1, 64, 64, 0, Math.PI * 2, 0, Math.PI / 2);
                    const rangeSphereMat = new THREE.MeshStandardMaterial({
                        color: catalogItem.fallbackColor,
                        transparent: true,
                        opacity: 0.22, // Légèrement plus opaque
                        roughness: 0.05,
                        metalness: 0.4,
                        emissive: catalogItem.fallbackColor,
                        emissiveIntensity: 0.3, // Plus de lueur
                        side: THREE.DoubleSide,
                        depthWrite: false
                    });
                    const rangeSphere = new THREE.Mesh(rangeSphereGeom, rangeSphereMat);
                    rangeSphere.rotation.x = Math.PI / 2;
                    rangeSphere.renderOrder = 10;
                    rangeSphere.raycast = () => {}; // Non interactif
                    rangeGroup.add(rangeSphere);

                    // GRILLE TACTIQUE (Subtile)
                    const gridGeom = new THREE.SphereGeometry(1.001, 32, 32, 0, Math.PI * 2, 0, Math.PI / 2);
                    const gridMat = new THREE.MeshBasicMaterial({
                        color: catalogItem.fallbackColor,
                        wireframe: true,
                        transparent: true,
                        opacity: 0.08, // Très léger
                        side: THREE.DoubleSide,
                        depthWrite: false
                    });
                    const rangeGrid = new THREE.Mesh(gridGeom, gridMat);
                    rangeGrid.rotation.x = Math.PI / 2;
                    rangeGrid.renderOrder = 11;
                    rangeGrid.raycast = () => {}; // Non interactif
                    rangeGroup.add(rangeGrid);

                    // Bordure opaque (Onde)
                    const rangeStrokeGeom = new THREE.RingGeometry(0.99, 1, 64);
                    const rangeStrokeMat = new THREE.MeshBasicMaterial({
                        color: catalogItem.fallbackColor,
                        side: THREE.DoubleSide
                    });
                    const rangeStroke = new THREE.Mesh(rangeStrokeGeom, rangeStrokeMat);
                    rangeGroup.add(rangeStroke);

                    rangeGroup.position.z = 0.15; // Légèrement au dessus de l'ombre

                    scene.add(group);
                    meshes.set(vData.instanceId, group);

                    if (catalogItem.modelUrl) {
                        loader.load(catalogItem.modelUrl, (gltf) => {
                            const model = gltf.scene;
                            model.rotation.x = Math.PI / 2;

                            // Correction de la visibilité des faces (DoubleSide) et activation des ombres
                            model.traverse(child => {
                                if (child.isMesh) {
                                    child.material.side = THREE.DoubleSide;
                                    child.castShadow = true;
                                    child.receiveShadow = true;
                                }
                            });

                            model.scale.set(catalogItem.scale || 1, catalogItem.scale || 1, catalogItem.scale || 1);
                            modelGroup.add(model);

                            // Cacher le cube si modèle chargé
                            mesh.visible = false;
                            nose.visible = false;
                        });
                    }
                }

                const group = meshes.get(vData.instanceId);
                const modelGroup = group.getObjectByName("modelGroup");
                const rangeGroup = group.getObjectByName("rangeGroup");

                // CALCUL DE LA POSITION RELATIVE À L'ANCRE EN MÈTRES
                const coord = mapboxgl.MercatorCoordinate.fromLngLat([vData.lng, vData.lat]);
                const metersPerUnit = 1 / anchorMercator.meterInMercatorCoordinateUnits();

                const dx = (coord.x - anchorMercator.x) * metersPerUnit + (vData.offsetX || 0);
                const dy = (anchorMercator.y - coord.y) * metersPerUnit + (vData.offsetY || 0);

                const currentExag = store.getState().terrainExaggeration;
                const effectiveTerrainAlt = vData.terrainAltitude * currentExag;
                const dz = effectiveTerrainAlt + (vData.altitudeOffset || 0);
                group.position.set(dx, dy, dz);

                // Application des rotations seulement au modelGroup
                const rotX = currentExag > 0 ? (vData.rotationX || 0) : 0;
                const rotY = currentExag > 0 ? (vData.rotationY || 0) : 0;

                modelGroup.rotation.set(
                    rotX * Math.PI / 180,
                    rotY * Math.PI / 180,
                    -(vData.heading || 0) * Math.PI / 180
                );
            });
        }
    };

    return customLayer;
}
