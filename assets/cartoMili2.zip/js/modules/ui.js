import { store } from '../store.js';
import { vehiclesCatalog, getVehicleById } from '../config/vehicles.js';
import { saveScene, loadScene } from './persistence.js';

export function initUI() {
    initCatalog();
    initHeaderControls();
    initEditorControls();

    // Subscribe to state changes
    store.subscribe('mode', updateModeIndicator);
    store.subscribe('selectedCatalogId', updateCatalogSelection);
    store.subscribe('selectedPlacedId', updateEditorPanel);
    store.subscribe('placedVehicles', updateEditorValuesIfSelectedChanged);
}

function initCatalog() {
    const list = document.getElementById('vehicle-list');
    vehiclesCatalog.forEach(v => {
        const li = document.createElement('li');
        li.className = 'vehicle-item';
        li.dataset.id = v.id;

        const colorHex = '#' + v.fallbackColor.toString(16).padStart(6, '0');

        const imgHtml = v.image ? `<img src="${v.image}" style="width: 100%; height: 100%; object-fit: cover;">` : '';

        li.innerHTML = `
            <div class="vehicle-icon" style="background-color: ${colorHex}; overflow: hidden;">${imgHtml}</div>
            <div class="vehicle-info">
                <h4>${v.name}</h4>
                <p>Portée: ${v.rangeKm} km</p>
            </div>
        `;

        li.addEventListener('click', () => {
            store.setState({ selectedCatalogId: v.id });
        });

        list.appendChild(li);
    });

    // Toggle panel
    const btnToggle = document.getElementById('btn-toggle-catalog');
    const panelCatalog = document.getElementById('panel-catalog');
    btnToggle.addEventListener('click', () => {
        panelCatalog.classList.toggle('open');
    });

    // Add button
    const btnAdd = document.getElementById('btn-add-vehicle');
    btnAdd.addEventListener('click', () => {
        const state = store.getState();
        if (state.selectedCatalogId) {
            store.setState({ mode: state.mode === 'placement' ? 'idle' : 'placement' });
        }
    });
}

function initHeaderControls() {
    document.getElementById('btn-save').addEventListener('click', saveScene);

    const fileInput = document.getElementById('file-input');
    document.getElementById('btn-load').addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            loadScene(e.target.files[0]);
            fileInput.value = ''; // Reset
        }
    });

    document.getElementById('btn-reset').addEventListener('click', () => {
        if (confirm("Voulez-vous vraiment supprimer tous les véhicules ?")) {
            store.clearAll();
        }
    });

    // Toggle Terrain
    const btnTerrain = document.getElementById('btn-terrain');
    btnTerrain.addEventListener('click', () => {
        const current = store.getState().terrainExaggeration;
        const next = current === 0 ? 1.5 : 0;
        store.setState({ terrainExaggeration: next });
    });

    store.subscribe('terrainExaggeration', (exag) => {
        btnTerrain.innerText = `Terrain 3D: ${exag > 0 ? 'ON' : 'OFF'}`;
        btnTerrain.className = exag > 0 ? 'btn btn-primary' : 'btn';
    });
}

function initEditorControls() {
    document.getElementById('btn-close-editor').addEventListener('click', () => {
        store.setState({ selectedPlacedId: null });
    });

    const inputHeading = document.getElementById('input-heading');
    inputHeading.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-heading').innerText = val + '°';
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.updatePlacedVehicle(state.selectedPlacedId, { heading: val });
        }
    });

    const inputRotX = document.getElementById('input-rotationX');
    inputRotX.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-rotationX').innerText = val + '°';
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.updatePlacedVehicle(state.selectedPlacedId, { rotationX: val });
        }
    });

    const inputRotY = document.getElementById('input-rotationY');
    inputRotY.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-rotationY').innerText = val + '°';
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.updatePlacedVehicle(state.selectedPlacedId, { rotationY: val });
        }
    });

    const inputPosX = document.getElementById('input-posX');
    inputPosX.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-posX').innerText = val + 'm';
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.updatePlacedVehicle(state.selectedPlacedId, { offsetX: val });
        }
    });

    const inputPosY = document.getElementById('input-posY');
    inputPosY.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-posY').innerText = val + 'm';
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.updatePlacedVehicle(state.selectedPlacedId, { offsetY: val });
        }
    });

    const inputOffset = document.getElementById('input-offset');
    inputOffset.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-offset').innerText = val + 'm';
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.updatePlacedVehicle(state.selectedPlacedId, { altitudeOffset: val });
        }
    });

    document.getElementById('btn-delete').addEventListener('click', () => {
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.removePlacedVehicle(state.selectedPlacedId);
        }
    });

    // Focus button logic is connected in map.js to have map context, or we trigger an event
    document.getElementById('btn-focus').addEventListener('click', () => {
        const state = store.getState();
        if (state.selectedPlacedId) {
            store.notify('focus_camera', state.selectedPlacedId);
        }
    });

    // Navigation entre véhicules
    document.getElementById('btn-prev-vehicle').addEventListener('click', () => navigateVehicles(-1));
    document.getElementById('btn-next-vehicle').addEventListener('click', () => navigateVehicles(1));
}

function navigateVehicles(direction) {
    const state = store.getState();
    const placed = state.placedVehicles;
    if (placed.length <= 1) return;

    const currentIndex = placed.findIndex(v => v.instanceId === state.selectedPlacedId);
    let nextIndex = currentIndex + direction;

    if (nextIndex < 0) nextIndex = placed.length - 1;
    if (nextIndex >= placed.length) nextIndex = 0;

    const nextId = placed[nextIndex].instanceId;
    store.setState({ selectedPlacedId: nextId });
}

function updateModeIndicator(mode) {
    const indicator = document.getElementById('mode-indicator');
    indicator.innerText = mode === 'placement' ? 'Mode: Placement (Double-Clic)' : 'Mode: Idle';
    indicator.className = mode === 'placement' ? 'badge placement' : 'badge';

    const btnAdd = document.getElementById('btn-add-vehicle');
    btnAdd.innerText = mode === 'placement' ? 'Annuler Placement' : 'Activer Placement';
}

function updateCatalogSelection(id) {
    document.querySelectorAll('.vehicle-item').forEach(el => {
        if (el.dataset.id === id) el.classList.add('selected');
        else el.classList.remove('selected');
    });

    const btnAdd = document.getElementById('btn-add-vehicle');
    btnAdd.disabled = !id;
}

function updateEditorPanel(selectedId) {
    const panel = document.getElementById('panel-editor');
    if (!selectedId) {
        panel.classList.add('hidden');
        return;
    }

    const state = store.getState();
    const vehicleData = state.placedVehicles.find(v => v.instanceId === selectedId);
    if (!vehicleData) return;

    panel.classList.remove('hidden');
    populateEditor(vehicleData);
}

function updateEditorValuesIfSelectedChanged(placedVehicles) {
    const state = store.getState();
    if (state.selectedPlacedId) {
        const vehicleData = placedVehicles.find(v => v.instanceId === state.selectedPlacedId);
        if (vehicleData) {
            populateEditor(vehicleData);
        } else {
            store.setState({ selectedPlacedId: null });
        }
    }
}

function populateEditor(vData) {
    const state = store.getState();
    const catalogItem = getVehicleById(vData.catalogId);

    // Update Vignette
    const imgElement = document.getElementById('vignette-img');
    const placeholder = document.getElementById('vignette-placeholder');
    const btnPrev = document.getElementById('btn-prev-vehicle');
    const btnNext = document.getElementById('btn-next-vehicle');

    // Afficher les flèches seulement si > 1 véhicule
    const showNav = state.placedVehicles.length > 1;
    btnPrev.classList.toggle('hidden', !showNav);
    btnNext.classList.toggle('hidden', !showNav);

    if (catalogItem && catalogItem.image) {
        imgElement.src = catalogItem.image;
        imgElement.style.display = 'block';
        placeholder.style.display = 'none';
    } else {
        imgElement.src = '';
        imgElement.style.display = 'none';
        placeholder.style.display = 'block';
    }

    document.getElementById('prop-name').innerText = catalogItem ? catalogItem.name : vData.catalogId;
    document.getElementById('prop-alt').innerText = vData.terrainAltitude.toFixed(1);

    const posXInput = document.getElementById('input-posX');
    posXInput.value = vData.offsetX || 0;
    document.getElementById('val-posX').innerText = (vData.offsetX || 0) + 'm';

    const posYInput = document.getElementById('input-posY');
    posYInput.value = vData.offsetY || 0;
    document.getElementById('val-posY').innerText = (vData.offsetY || 0) + 'm';

    const headingInput = document.getElementById('input-heading');
    headingInput.value = vData.heading || 0;
    document.getElementById('val-heading').innerText = (vData.heading || 0) + '°';

    const currentExag = store.getState().terrainExaggeration;

    const rotXInput = document.getElementById('input-rotationX');
    const rotXValue = currentExag > 0 ? (vData.rotationX || 0) : 0;
    rotXInput.value = rotXValue;
    rotXInput.disabled = currentExag === 0;
    document.getElementById('val-rotationX').innerText = rotXValue + '°';

    const rotYInput = document.getElementById('input-rotationY');
    const rotYValue = currentExag > 0 ? (vData.rotationY || 0) : 0;
    rotYInput.value = rotYValue;
    rotYInput.disabled = currentExag === 0;
    document.getElementById('val-rotationY').innerText = rotYValue + '°';

    const offsetInput = document.getElementById('input-offset');
    offsetInput.value = vData.altitudeOffset || 0;
    document.getElementById('val-offset').innerText = (vData.altitudeOffset || 0) + 'm';
}
