import { store } from '../store.js';

export function saveScene() {
    const state = store.getState();
    const data = {
        version: "1.0",
        timestamp: new Date().toISOString(),
        vehicles: state.placedVehicles
    };

    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `cartoMili_scene_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    
    // Cleanup
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 100);
}

export function loadScene(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            if (data.version && data.vehicles && Array.isArray(data.vehicles)) {
                store.setState({ selectedPlacedId: null });
                // On vide d'abord pour réinitialiser l'ancre dans threeLayer
                store.setPlacedVehicles([]); 
                // Puis on charge les nouveaux
                store.setPlacedVehicles(data.vehicles);
                // Notifier pour le focus caméra et le repaint
                store.notify('scene_loaded', data.vehicles);
                console.log("Scène chargée avec succès !");
            } else {
                alert("Format de fichier JSON invalide ou incompatible.");
            }
        } catch (error) {
            console.error("Erreur lors de la lecture du fichier JSON:", error);
            alert("Erreur lors de la lecture du fichier.");
        }
    };
    reader.readAsText(file);
}
