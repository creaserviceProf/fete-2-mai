// Pattern simple Pub/Sub pour le state management

const state = {
    mode: 'idle', // 'idle' ou 'placement'
    selectedCatalogId: null, // ID du véhicule sélectionné dans le panneau gauche
    placedVehicles: [], // Liste des véhicules placés sur la carte
    selectedPlacedId: null, // ID du véhicule sélectionné sur la carte (pour édition)
    terrainExaggeration: 0 // 0 ou 1.5
};

const listeners = {};

export const store = {
    getState() {
        return state;
    },

    setState(newState) {
        let changed = false;
        for (const key in newState) {
            if (state[key] !== newState[key]) {
                state[key] = newState[key];
                changed = true;
                this.notify(key, state[key]);
            }
        }
        if (changed) {
            this.notify('all', state);
        }
    },

    subscribe(key, callback) {
        if (!listeners[key]) {
            listeners[key] = [];
        }
        listeners[key].push(callback);
    },

    notify(key, value) {
        if (listeners[key]) {
            listeners[key].forEach(cb => cb(value));
        }
    },
    
    addPlacedVehicle(vehicle) {
        const newList = [...state.placedVehicles, vehicle];
        this.setState({ placedVehicles: newList });
    },
    
    setPlacedVehicles(vehicles) {
        this.setState({ placedVehicles: vehicles });
    },
    
    updatePlacedVehicle(id, updates) {
        const newList = state.placedVehicles.map(v => 
            v.instanceId === id ? { ...v, ...updates } : v
        );
        this.setState({ placedVehicles: newList });
    },
    
    removePlacedVehicle(id) {
        const newList = state.placedVehicles.filter(v => v.instanceId !== id);
        this.setState({ placedVehicles: newList });
        if (state.selectedPlacedId === id) {
            this.setState({ selectedPlacedId: null });
        }
    },
    
    clearAll() {
        this.setState({
            placedVehicles: [],
            selectedPlacedId: null,
            mode: 'idle'
        });
    }
};
