export const vehiclesCatalog = [
    {
        id: "v_suv",
        name: "SUV Tactique",
        category: "Léger",
        description: "Véhicule utilitaire rapide et polyvalent.",
        rangeKm: 5, // 5km de portée pour le cercle visuel
        scale: 2, // Échelle 1 = 1 mètre env dans notre fallback
        modelUrl: "js/assets/rapidranger.glb",
        image: "js/assets/rapidranger.jpg",
        fallbackColor: 0x4a90e2, // Bleu
        fallbackType: "box",
        dimensions: { length: 4.5, width: 2, height: 1.8 } // en mètres
    },
    {
        id: "v_tent",
        name: "tent Tactique",
        category: "Léger",
        description: "Véhicule utilitaire rapide et polyvalent.",
        rangeKm: 1, // 5km de portée pour le cercle visuel
        scale: 6, // Échelle 1 = 1 mètre env dans notre fallback
        modelUrl: "js/assets/tenteC2.glb",
        image: "js/assets/c2Tent.jpg",
        fallbackColor: 0x333333, // Bleu
        fallbackType: "box",
        dimensions: { length: 4.5, width: 2, height: 1.8 } // en mètres
    },

    {
        id: "v_truck",
        name: "Camion Logistique",
        category: "Lourd",
        description: "Transport de troupes et matériel.",
        rangeKm: 8,
        scale: 1,
        modelUrl: "",
        image: "",
        fallbackColor: 0x27ae60, // Vert
        fallbackType: "box",
        dimensions: { length: 8, width: 2.5, height: 3.2 }
    },
    {
        id: "v_armor",
        name: "Véhicule Blindé",
        category: "Combat",
        description: "Reconnaissance et appui feu.",
        rangeKm: 12,
        scale: 6,
        modelUrl: "js/assets/lancemissile1.glb",
        image: "js/assets/lancemissile1.jpg",
        fallbackColor: 0xc0392b, // Rouge
        fallbackType: "box",
        dimensions: { length: 18, width: 16.8, height: 15 }
    }
];

export function getVehicleById(id) {
    return vehiclesCatalog.find(v => v.id === id);
}
